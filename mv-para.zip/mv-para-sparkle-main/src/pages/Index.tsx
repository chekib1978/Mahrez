import Header from "@/components/site/Header";
import Hero from "@/components/site/Hero";
import Promesses from "@/components/site/Promesses";
import Categories from "@/components/site/Categories";
import Produits from "@/components/site/Produits";
import Editorial from "@/components/site/Editorial";
import Marques from "@/components/site/Marques";
import Newsletter from "@/components/site/Newsletter";
import Footer from "@/components/site/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <Promesses />
        <Categories />
        <Produits />
        <Editorial />
        <Marques />
        <Newsletter />
      </main>
      <Footer />
    </div>
  );
};

export default Index;

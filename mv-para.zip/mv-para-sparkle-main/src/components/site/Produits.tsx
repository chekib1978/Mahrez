import { Heart, ShoppingBag, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import p1 from "@/assets/product-1.jpg";
import p2 from "@/assets/product-2.jpg";
import p3 from "@/assets/product-3.jpg";
import p4 from "@/assets/product-4.jpg";

const products = [
  { img: p1, brand: "La Roche-Posay", name: "Sérum Hyalu B5 Anti-rides", price: 89, old: 109, tag: "Best-seller" },
  { img: p2, brand: "Avène", name: "Crème Hydratante Tolérance", price: 64, old: null, tag: "Nouveau" },
  { img: p3, brand: "Bioderma", name: "Sensibio H2O Eau Micellaire", price: 42, old: 49, tag: "-15%" },
  { img: p4, brand: "Nuxe Sun", name: "Crème Solaire SPF 50 Visage", price: 78, old: null, tag: null },
];

const Produits = () => (
  <section className="py-20 lg:py-28 gradient-soft">
    <div className="container">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <p className="text-accent-deep text-sm font-medium tracking-widest uppercase mb-3">Sélection</p>
        <h2 className="font-display text-4xl md:text-5xl text-primary mb-4">Nos coups de cœur</h2>
        <p className="text-muted-foreground">Une sélection exclusive de nos pharmaciens pour révéler le meilleur de vous-même.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 lg:gap-7">
        {products.map((p) => (
          <article key={p.name} className="group bg-card rounded-2xl overflow-hidden shadow-card hover:shadow-elegant transition-smooth">
            <div className="relative aspect-square overflow-hidden bg-secondary">
              {p.tag && (
                <span className="absolute top-3 left-3 z-10 px-3 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider gradient-gold text-white shadow-soft">
                  {p.tag}
                </span>
              )}
              <button className="absolute top-3 right-3 z-10 h-9 w-9 rounded-full bg-card/90 backdrop-blur flex items-center justify-center text-muted-foreground hover:text-accent-deep transition-smooth shadow-soft">
                <Heart className="h-4 w-4" />
              </button>
              <img
                src={p.img}
                alt={p.name}
                loading="lazy"
                className="h-full w-full object-cover group-hover:scale-105 transition-spring"
              />
              <Button
                size="sm"
                className="absolute bottom-3 left-3 right-3 gradient-primary text-primary-foreground rounded-full opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-smooth"
              >
                <ShoppingBag className="h-4 w-4 mr-2" /> Ajouter
              </Button>
            </div>
            <div className="p-5">
              <p className="text-[11px] uppercase tracking-widest text-accent-deep font-semibold mb-1">{p.brand}</p>
              <h3 className="text-sm font-medium text-foreground line-clamp-2 min-h-[40px] mb-2">{p.name}</h3>
              <div className="flex items-center gap-1 text-accent mb-3">
                {[...Array(5)].map((_, i) => <Star key={i} className="h-3 w-3 fill-current" />)}
                <span className="text-xs text-muted-foreground ml-1">(124)</span>
              </div>
              <div className="flex items-baseline gap-2">
                <span className="font-display text-xl text-primary">{p.price} DT</span>
                {p.old && <span className="text-xs text-muted-foreground line-through">{p.old} DT</span>}
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  </section>
);

export default Produits;

import { Heart, Search, ShoppingBag, User, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";

const navItems = [
  "Visage", "Corps", "Cheveux", "Maman & Bébé", "Compléments", "Parfums", "Promotions",
];

const Header = () => {
  return (
    <header className="sticky top-0 z-50 w-full">
      {/* Top bar */}
      <div className="bg-primary text-primary-foreground text-xs">
        <div className="container flex h-9 items-center justify-between">
          <p className="hidden sm:block tracking-wide">
            Livraison <span className="text-accent">offerte</span> dès 150 DT — Conseil pharmaceutique 7j/7
          </p>
          <div className="flex items-center gap-5">
            <a href="#" className="hover:text-accent transition-smooth">Mon compte</a>
            <a href="#" className="hover:text-accent transition-smooth">Suivi commande</a>
            <a href="#" className="hover:text-accent transition-smooth">Aide</a>
          </div>
        </div>
      </div>

      {/* Main bar */}
      <div className="bg-background/90 backdrop-blur-md border-b border-border">
        <div className="container flex h-20 items-center justify-between gap-6">
          <a href="/" className="flex items-baseline gap-1">
            <span className="font-display text-3xl font-semibold tracking-tight text-primary">MV</span>
            <span className="font-display text-3xl font-light text-accent-deep">PARA</span>
          </a>

          <div className="hidden md:flex flex-1 max-w-xl">
            <div className="relative w-full">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Rechercher un produit, une marque…"
                className="w-full h-11 pl-11 pr-4 rounded-full bg-muted/60 border border-transparent focus:bg-background focus:border-primary/30 outline-none transition-smooth text-sm"
              />
            </div>
          </div>

          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="rounded-full"><User className="h-5 w-5" /></Button>
            <Button variant="ghost" size="icon" className="rounded-full hidden sm:inline-flex"><Heart className="h-5 w-5" /></Button>
            <Button variant="ghost" size="icon" className="rounded-full relative">
              <ShoppingBag className="h-5 w-5" />
              <span className="absolute -top-0.5 -right-0.5 h-5 w-5 rounded-full gradient-gold text-[10px] font-semibold text-white flex items-center justify-center shadow-soft">2</span>
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full md:hidden"><Menu className="h-5 w-5" /></Button>
          </div>
        </div>

        {/* Nav */}
        <nav className="hidden md:block border-t border-border/60">
          <div className="container">
            <ul className="flex items-center justify-center gap-8 h-12 text-sm">
              {navItems.map((item) => (
                <li key={item}>
                  <a
                    href="#"
                    className="relative font-medium text-foreground/80 hover:text-primary transition-smooth after:content-[''] after:absolute after:bottom-[-14px] after:left-0 after:h-[2px] after:w-0 hover:after:w-full after:bg-accent after:transition-all"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;

import { Facebook, Instagram, MapPin, Phone, Mail } from "lucide-react";

const Footer = () => (
  <footer className="bg-primary text-primary-foreground">
    <div className="container py-16 grid lg:grid-cols-5 gap-10">
      <div className="lg:col-span-2 space-y-5">
        <div className="flex items-baseline gap-1">
          <span className="font-display text-3xl font-semibold">MV</span>
          <span className="font-display text-3xl font-light text-accent">PARA</span>
        </div>
        <p className="text-primary-foreground/70 text-sm leading-relaxed max-w-sm">
          Votre parapharmacie en ligne premium. Sélection rigoureuse, conseil pharmaceutique, livraison rapide partout en Tunisie.
        </p>
        <div className="flex gap-3">
          {[Facebook, Instagram].map((Icon, i) => (
            <a key={i} href="#" className="h-10 w-10 rounded-full border border-primary-foreground/20 flex items-center justify-center hover:bg-accent hover:border-accent hover:text-accent-foreground transition-smooth">
              <Icon className="h-4 w-4" />
            </a>
          ))}
        </div>
      </div>

      {[
        { title: "Boutique", links: ["Visage", "Corps", "Cheveux", "Bébé", "Compléments"] },
        { title: "Service client", links: ["Contact", "Livraison", "Retours", "FAQ", "Suivi commande"] },
        { title: "À propos", links: ["Notre histoire", "Nos pharmaciens", "Marques", "Blog beauté", "Carrières"] },
      ].map((col) => (
        <div key={col.title}>
          <h4 className="font-display text-lg text-accent mb-4">{col.title}</h4>
          <ul className="space-y-2.5 text-sm">
            {col.links.map((l) => (
              <li key={l}>
                <a href="#" className="text-primary-foreground/70 hover:text-accent transition-smooth">{l}</a>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>

    <div className="border-t border-primary-foreground/10">
      <div className="container py-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-primary-foreground/60">
        <p>© 2026 MV PARA — Tous droits réservés.</p>
        <div className="flex items-center gap-5">
          <span className="inline-flex items-center gap-1.5"><Phone className="h-3.5 w-3.5" /> +216 70 000 000</span>
          <span className="inline-flex items-center gap-1.5"><Mail className="h-3.5 w-3.5" /> contact@mvpara.tn</span>
          <span className="hidden md:inline-flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> Tunis, Tunisie</span>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;

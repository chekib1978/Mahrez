import visage from "@/assets/cat-visage.jpg";
import corps from "@/assets/cat-corps.jpg";
import cheveux from "@/assets/cat-cheveux.jpg";
import bebe from "@/assets/cat-bebe.jpg";
import complements from "@/assets/cat-complements.jpg";
import { ArrowUpRight } from "lucide-react";

const cats = [
  { title: "Soins du visage", count: "+ 1 200 produits", img: visage, span: "lg:col-span-2 lg:row-span-2" },
  { title: "Corps & hygiène", count: "+ 850 produits", img: corps },
  { title: "Cheveux", count: "+ 420 produits", img: cheveux },
  { title: "Maman & Bébé", count: "+ 600 produits", img: bebe },
  { title: "Compléments", count: "+ 380 produits", img: complements },
];

const Categories = () => (
  <section className="py-20 lg:py-28">
    <div className="container">
      <div className="flex items-end justify-between mb-12 gap-6">
        <div>
          <p className="text-accent-deep text-sm font-medium tracking-widest uppercase mb-3">Univers</p>
          <h2 className="font-display text-4xl md:text-5xl text-primary max-w-xl">Nos catégories phares</h2>
        </div>
        <a href="#" className="hidden md:inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-accent-deep transition-smooth">
          Voir tout <ArrowUpRight className="h-4 w-4" />
        </a>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 lg:grid-rows-2 gap-4 lg:gap-6 lg:h-[640px]">
        {cats.map((c) => (
          <a
            key={c.title}
            href="#"
            className={`group relative overflow-hidden rounded-3xl shadow-card hover:shadow-elegant transition-smooth ${c.span ?? ""}`}
          >
            <img
              src={c.img}
              alt={c.title}
              loading="lazy"
              className="absolute inset-0 h-full w-full object-cover group-hover:scale-105 transition-spring"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-primary/10 to-transparent" />
            <div className="relative h-full min-h-[200px] flex flex-col justify-end p-6 text-primary-foreground">
              <p className="text-xs uppercase tracking-widest opacity-80 mb-1">{c.count}</p>
              <h3 className="font-display text-2xl lg:text-3xl">{c.title}</h3>
              <span className="mt-3 inline-flex items-center gap-1 text-sm opacity-0 group-hover:opacity-100 -translate-y-2 group-hover:translate-y-0 transition-smooth">
                Découvrir <ArrowUpRight className="h-4 w-4" />
              </span>
            </div>
          </a>
        ))}
      </div>
    </div>
  </section>
);

export default Categories;

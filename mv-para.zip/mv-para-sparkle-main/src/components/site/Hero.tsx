import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";
import heroImg from "@/assets/hero-mvpara.jpg";

const Hero = () => {
  return (
    <section className="relative overflow-hidden gradient-hero">
      <div className="container grid lg:grid-cols-2 gap-12 items-center py-16 lg:py-24">
        <div className="space-y-8 animate-fade-up">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent-soft border border-accent/30 text-accent-deep text-xs font-medium">
            <Sparkles className="h-3.5 w-3.5" />
            Nouvelle collection — Printemps 2026
          </div>

          <h1 className="font-display text-5xl md:text-6xl lg:text-7xl leading-[1.05] text-primary">
            La beauté qui prend
            <span className="block italic text-gold"> soin de vous.</span>
          </h1>

          <p className="text-lg text-muted-foreground max-w-lg leading-relaxed">
            Découvrez plus de <span className="text-foreground font-medium">10 000 produits</span> de parapharmacie, dermo-cosmétique et bien-être, sélectionnés par nos pharmaciens.
          </p>

          <div className="flex flex-wrap items-center gap-4">
            <Button size="lg" className="gradient-primary text-primary-foreground hover:opacity-90 rounded-full px-8 h-12 shadow-elegant">
              Découvrir la boutique
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="rounded-full px-8 h-12 border-primary/20 hover:bg-primary-soft">
              Nos marques
            </Button>
          </div>

          <div className="flex items-center gap-8 pt-4">
            {[
              { num: "10K+", label: "Produits" },
              { num: "150+", label: "Marques" },
              { num: "4.9★", label: "Avis clients" },
            ].map((s) => (
              <div key={s.label}>
                <div className="font-display text-2xl text-primary">{s.num}</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider">{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="relative animate-scale-in">
          <div className="absolute -inset-4 gradient-gold opacity-20 blur-3xl rounded-full" />
          <div className="relative rounded-3xl overflow-hidden shadow-elegant">
            <img
              src={heroImg}
              alt="Sélection premium de produits parapharmaceutiques MV PARA"
              width={1600}
              height={1100}
              className="w-full h-[520px] object-cover"
            />
          </div>
          <div className="absolute -bottom-6 -left-6 bg-card rounded-2xl p-5 shadow-elegant max-w-[220px] hidden md:block">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full gradient-gold flex items-center justify-center text-white">
                <Sparkles className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Conseil expert</div>
                <div className="text-sm font-semibold text-primary">Pharmacien à l'écoute</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;

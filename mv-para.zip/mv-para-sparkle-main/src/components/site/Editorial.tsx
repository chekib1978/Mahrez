import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import img from "@/assets/cat-visage.jpg";

const Editorial = () => (
  <section className="py-20 lg:py-28">
    <div className="container">
      <div className="relative overflow-hidden rounded-[2rem] gradient-primary text-primary-foreground">
        <div className="grid lg:grid-cols-2 gap-0 items-center">
          <div className="p-10 lg:p-16 space-y-6 relative z-10">
            <p className="text-accent text-sm font-medium tracking-widest uppercase">Engagement MV PARA</p>
            <h2 className="font-display text-4xl md:text-5xl leading-tight">
              Des conseils <em className="text-accent not-italic">d'experts</em>, pour chaque type de peau.
            </h2>
            <p className="text-primary-foreground/80 leading-relaxed max-w-md">
              Notre équipe de pharmaciens diplômés vous accompagne dans le choix des produits adaptés à vos besoins. Profitez de diagnostics personnalisés et de routines sur-mesure.
            </p>
            <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent-deep hover:text-white rounded-full px-8 h-12 shadow-gold">
              Diagnostic gratuit <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          <div className="relative h-80 lg:h-[520px]">
            <img src={img} alt="Conseil pharmacien" loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/40 to-transparent lg:from-primary/0 lg:via-transparent" />
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default Editorial;
